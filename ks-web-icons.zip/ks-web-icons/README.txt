Web & E-commerce Line Icons (40 SVG icons)
by Justas Arbatauskis - https://kokybiskasvetaine.lt/

40 line icons for business websites and online stores: cart, parcel box, delivery truck,
parcel locker, payment card, price tag, lock, shield, chat, map pin, speedometer,
code brackets and more.

- 24 x 24 px grid, 1.75 px round stroke, stroke="currentColor", fill="none"
- svg/      individual SVG files (inherit the text colour via currentColor)
- sprite.svg  all icons as <symbol id="ks-NAME"> for <svg><use href="sprite.svg#ks-cart"/></svg>
- png-64/, png-256/  PNG exports (transparent background, dark stroke)

Usage in HTML:
  <svg width="24" height="24"><use href="sprite.svg#ks-cart"></use></svg>

License: MIT (see LICENSE.txt). Free for personal and commercial use.
Attribution is appreciated but not required.
